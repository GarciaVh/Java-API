 <h3> Bem vindo ao nosso Crud feito com Spring Boot com o tema sendo baseado em uma empresa de jogos indie</h3>

<h3> Alunos: </h3>

Igor Yudi Tsuruda <br /> 
Leonardo Dias Santana Ribeiro <br /> 
Vitor Hugo Garcia Mariano <br />
<br />
<h3> <a href="https://www.youtube.com/watch?v=8FXCVqYpOis">Video da apresentação do projeto e suas funcionalidades</a> </h3>
